-- =====================================================================
-- HABERLER TABLOSU (kamu ilanlarıyla ilgili haber başlıkları)
-- Supabase > SQL Editor > New query > yapıştır > Run  (tekrar çalıştırılabilir)
-- =====================================================================
CREATE TABLE IF NOT EXISTS public.haberler (
  id           uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  baslik       text        NOT NULL,
  kaynak       text,
  link         text        NOT NULL,
  yayin_tarihi timestamptz NOT NULL DEFAULT now(),
  created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS haberler_link_unique ON public.haberler (link);
CREATE INDEX IF NOT EXISTS haberler_tarih_idx ON public.haberler (yayin_tarihi DESC);

ALTER TABLE public.haberler ENABLE ROW LEVEL SECURITY;

-- Ziyaretçiler sadece okuyabilir; yazmayı bot (secret key) yapar.
DROP POLICY IF EXISTS "haberler herkese okunur" ON public.haberler;
CREATE POLICY "haberler herkese okunur"
  ON public.haberler FOR SELECT TO anon, authenticated USING (true);

REVOKE ALL ON public.haberler FROM anon, authenticated;
GRANT SELECT ON public.haberler TO anon, authenticated;
