-- =====================================================================
-- KAMU İLANLARI - GÜVENLİK (RLS) VE ŞEMA DÜZENLEMESİ
-- Supabase > SQL Editor > New query > yapıştır > Run
-- Birden fazla kez çalıştırılabilir (idempotent).
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1) İlan tablosuna yeni sütunlar
-- ---------------------------------------------------------------------
ALTER TABLE public.tum_kamu_ilanlari
  ADD COLUMN IF NOT EXISTS aktif_mi       boolean     NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS son_gorulme    timestamptz NOT NULL DEFAULT now(),
  ADD COLUMN IF NOT EXISTS detay_islendi  boolean     NOT NULL DEFAULT false;

-- ---------------------------------------------------------------------
-- 1b) Sütun uzunluk sınırlarını kaldır (varchar(100) "value too long" hatası verdi)
-- ---------------------------------------------------------------------
ALTER TABLE public.tum_kamu_ilanlari
  ALTER COLUMN baslik          TYPE text,
  ALTER COLUMN kurum_adi       TYPE text,
  ALTER COLUMN ilan_turu       TYPE text,
  ALTER COLUMN sehir           TYPE text,
  ALTER COLUMN mezuniyet_sarti TYPE text,
  ALTER COLUMN kpss_turu       TYPE text,
  ALTER COLUMN basvuru_linki   TYPE text;

-- Aynı ilanın iki kez kaydedilmesini önleyen kısıt (zaten varsa dokunmaz)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'unique_ilan_kaynak'
      AND conrelid = 'public.tum_kamu_ilanlari'::regclass
  ) THEN
    ALTER TABLE public.tum_kamu_ilanlari
      ADD CONSTRAINT unique_ilan_kaynak UNIQUE (kaynak_sistem, orijinal_ilan_id);
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_ilan_aktif_tarih
  ON public.tum_kamu_ilanlari (aktif_mi, son_basvuru_tarihi);
CREATE INDEX IF NOT EXISTS idx_ilan_kaynak
  ON public.tum_kamu_ilanlari (kaynak_sistem, aktif_mi);

-- ---------------------------------------------------------------------
-- 2) Bozuk İŞKUR kayıtlarını temizle
--    (eski botların uydurduğu "iskur_..." ID'li ve boş başlıklı satırlar)
-- ---------------------------------------------------------------------
DELETE FROM public.tum_kamu_ilanlari
WHERE kaynak_sistem = 'ISKUR'
  AND (
        baslik IN ('Kamu İşçisi', 'Belirtilmemiş')
     OR orijinal_ilan_id LIKE 'iskur\_%' ESCAPE '\'
  );

-- ---------------------------------------------------------------------
-- 3) Aboneler tablosu (yoksa oluştur) + doğrulamalar
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.aboneler (
  id         bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  email      text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.aboneler
  ADD COLUMN IF NOT EXISTS kvkk_onay boolean NOT NULL DEFAULT false;

-- Aynı e-posta iki kez kaydedilmesin (mevcut tekrarları önce temizle)
DELETE FROM public.aboneler a
USING public.aboneler b
WHERE a.id > b.id AND lower(a.email) = lower(b.email);

CREATE UNIQUE INDEX IF NOT EXISTS aboneler_email_unique
  ON public.aboneler (lower(email));

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'aboneler_email_format'
      AND conrelid = 'public.aboneler'::regclass
  ) THEN
    ALTER TABLE public.aboneler
      ADD CONSTRAINT aboneler_email_format
      CHECK (length(email) <= 254 AND email ~* '^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$')
      NOT VALID;
  END IF;
END $$;

-- ---------------------------------------------------------------------
-- 4) ROW LEVEL SECURITY (RLS)
--    * Botlar "secret key" (sb_secret_...) kullanır -> RLS'yi aşar, yazabilir.
--    * Web sitesi "publishable key" kullanır -> sadece aşağıdaki izinler.
-- ---------------------------------------------------------------------
ALTER TABLE public.tum_kamu_ilanlari ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.aboneler          ENABLE ROW LEVEL SECURITY;

-- İlanlar: herkes sadece AKTİF ilanları okuyabilir; yazma/silme yok.
DROP POLICY IF EXISTS "ilanlar herkese okunur" ON public.tum_kamu_ilanlari;
CREATE POLICY "ilanlar herkese okunur"
  ON public.tum_kamu_ilanlari
  FOR SELECT TO anon, authenticated
  USING (aktif_mi = true);

-- Aboneler: ziyaretçi sadece KVKK onayıyla kayıt ekleyebilir; okuyamaz,
-- güncelleyemez, silemez.
DROP POLICY IF EXISTS "abone ekle" ON public.aboneler;
CREATE POLICY "abone ekle"
  ON public.aboneler
  FOR INSERT TO anon, authenticated
  WITH CHECK (kvkk_onay = true);

-- Gereksiz yetkileri kaldır (RLS'ye ek olarak ikinci güvenlik katmanı)
REVOKE ALL ON public.tum_kamu_ilanlari FROM anon, authenticated;
GRANT  SELECT ON public.tum_kamu_ilanlari TO anon, authenticated;

REVOKE ALL ON public.aboneler FROM anon, authenticated;
GRANT  INSERT ON public.aboneler TO anon, authenticated;

-- ---------------------------------------------------------------------
-- 5) Artık kullanılmayan eski tablo
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS public.iskur_ilanlari;

-- ---------------------------------------------------------------------
-- 6) KONTROL: aşağıdaki iki satırda rls_acik = true olmalı
-- ---------------------------------------------------------------------
SELECT relname AS tablo, relrowsecurity AS rls_acik
FROM pg_class
WHERE relname IN ('tum_kamu_ilanlari', 'aboneler');
